import os
import numpy as np
import tensorflow as tf
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from transformers import DistilBertTokenizer, TFDistilBertModel
from sklearn.model_selection import train_test_split
import pandas as pd

# Flask App Configuration
app = Flask(__name__)
CORS(app)

# Disable TensorFlow warnings
tf.get_logger().setLevel('ERROR')

# Load the dataset
data = pd.read_csv('dataset.csv')

# Get the text data and labels
texts = data['text'].tolist()
labels = data['label'].tolist()

# Split data into training (80%) and test (20%) sets, maintaining the label balance
X_train, X_test, y_train, y_test = train_test_split(
    texts, labels, 
    test_size=0.2,  
    random_state=42,
    stratify=labels  
)

# Load the DistilBERT tokenizer
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')

# Tokenize the texts
def tokenize_texts(texts, max_length=128):
    input_ids = []
    attention_masks = []
    
    for text in texts:
        encoded_data = tokenizer.encode_plus(
            text,
            add_special_tokens=True,
            max_length=max_length,
            padding='max_length',
            return_attention_mask=True,
            truncation=True,
            return_tensors='tf'
        )
        input_ids.append(encoded_data['input_ids'])
        attention_masks.append(encoded_data['attention_mask'])
    
    return tf.concat(input_ids, axis=0), tf.concat(attention_masks, axis=0)

# Tokenize training and test data
X_train_ids, X_train_masks = tokenize_texts(X_train)
X_test_ids, X_test_masks = tokenize_texts(X_test)

# Convert labels to numpy
y_train = tf.convert_to_tensor(y_train).numpy()
y_test = tf.convert_to_tensor(y_test).numpy()

# Load the DistilBERT model
distilbert_model = TFDistilBertModel.from_pretrained('distilbert-base-uncased')

# Build the LSTM+DistilBERT model
def build_model(max_length=128, embedding_dim=768):
    # Input layers
    input_ids_layer = tf.keras.layers.Input(shape=(max_length,), dtype=tf.int32, name='input_ids')
    attention_mask_layer = tf.keras.layers.Input(shape=(max_length,), dtype=tf.int32, name='attention_mask')
    
    # DistilBERT embeddings
    bert_outputs = distilbert_model(input_ids_layer, attention_mask=attention_mask_layer)
    sequence_output = bert_outputs.last_hidden_state
    
    # LSTM layer
    lstm_output = tf.keras.layers.Bidirectional(
        tf.keras.layers.LSTM(64, return_sequences=False)
    )(sequence_output)
    
    # Dropout for regularization
    dropout = tf.keras.layers.Dropout(0.3)(lstm_output)
    
    # Dense layers
    dense1 = tf.keras.layers.Dense(32, activation='relu')(dropout)
    output = tf.keras.layers.Dense(1, activation='sigmoid')(dense1)
    
    model = tf.keras.Model(
        inputs=[input_ids_layer, attention_mask_layer], 
        outputs=output
    )
    return model

# Create and compile the model
model = build_model()
optimizer = tf.keras.optimizers.Adam(learning_rate=2e-5)
model.compile(optimizer=optimizer, loss='binary_crossentropy', metrics=['accuracy'])

# Training with early stopping
callbacks = [
    tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)
]

history = model.fit(
    x={'input_ids': X_train_ids, 'attention_mask': X_train_masks},
    y=y_train,
    validation_split=0.1,
    epochs=5,
    batch_size=16,
    callbacks=callbacks
)

# Prediction function
def predict_text(text, max_length=128):
    encoded_data = tokenizer.encode_plus(
        text,
        add_special_tokens=True,
        max_length=max_length,
        padding='max_length',
        truncation=True,
        return_attention_mask=True,
        return_tensors='tf'
    )

    input_ids = encoded_data['input_ids']
    attention_mask = encoded_data['attention_mask']

    prediction = model.predict({'input_ids': input_ids, 'attention_mask': attention_mask})
    return float(prediction[0][0])

# Flask Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def classify_text():
    data = request.json
    text = data.get('text', '')
    
    if not text:
        return jsonify({'error': 'No text provided'}), 400
    
    try:
        prediction_prob = predict_text(text)
        label = 'AI-generated' if prediction_prob > 0.5 else 'Human-written'
        confidence = prediction_prob if prediction_prob > 0.5 else 1 - prediction_prob
        
        return jsonify({
            'prediction_prob': prediction_prob,
            'label': label,
            'confidence': confidence
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)