import torch
import torch.nn as nn
import torch.optim as optim
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import string
from transformers import DistilBertTokenizer, DistilBertModel
import json
import pickle
import os

def setup_nltk():
    """Download required NLTK data."""
    print("Downloading NLTK data...")
    nltk.download('punkt')
    nltk.download('stopwords')
    nltk.download('punkt_tab')

def preprocess_text(text):
    """Preprocess text for analysis."""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in set(stopwords.words('english'))]
    return ' '.join(tokens)

class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, _ = self.lstm(embedded)
        out = lstm_out[:, -1, :]
        out = self.fc(out)
        return out

def tokenize_and_pad(text, word_to_idx, max_length=512):
    """Tokenize and pad text for LSTM processing."""
    tokens = preprocess_text(text).split()
    sequence = [word_to_idx.get(token, word_to_idx['<UNK>']) for token in tokens]
    if len(sequence) < max_length:
        sequence = sequence + [word_to_idx['<PAD>']] * (max_length - len(sequence))
    else:
        sequence = sequence[:max_length]
    return torch.tensor(sequence, dtype=torch.long)

def create_vocabulary(dataset_files):
    """Create vocabulary from dataset files."""
    print("Creating vocabulary...")
    all_texts = []
    for file_path in dataset_files:
        if os.path.exists(file_path):
            with open(file_path, 'r', encoding='utf-8') as f:
                all_texts.extend([line.strip() for line in f])
        else:
            print(f"Warning: {file_path} not found. Skipping...")
    
    all_tokens = [token for text in all_texts for token in preprocess_text(text).split()]
    vocab = set(all_tokens)
    
    # Create word to index mapping
    word_to_idx = {word: idx for idx, word in enumerate(vocab, 1)}
    word_to_idx['<PAD>'] = 0
    word_to_idx['<UNK>'] = len(word_to_idx)
    
    # Save vocabulary
    with open('word_to_idx.json', 'w') as f:
        json.dump(word_to_idx, f)
    
    return word_to_idx, all_texts

def train_model(lstm_model, distilbert_model, texts, word_to_idx, epochs=5, lr=0.001):
    """Train the LSTM model."""
    print(f"Training LSTM model for {epochs} epochs...")
    criterion = nn.MSELoss()
    optimizer = optim.Adam(lstm_model.parameters(), lr=lr)
    
    lstm_model.train()
    for epoch in range(epochs):
        total_loss = 0
        for text in texts:
            sequence = tokenize_and_pad(text, word_to_idx).unsqueeze(0)
            optimizer.zero_grad()
            outputs = lstm_model(sequence)
            
            # Use self-supervised learning approach
            target = outputs.detach()  # Using model's own output as target
            loss = criterion(outputs, target)
            
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
        
        avg_loss = total_loss / len(texts)
        print(f'Epoch {epoch + 1}/{epochs}, Average Loss: {avg_loss:.4f}')

def save_models(lstm_model, distilbert_model, distilbert_tokenizer):
    """Save all models and tokenizer."""
    print("Saving models and tokenizer...")
    
    # Save LSTM model
    with open('lstm_model.pkl', 'wb') as f:
        pickle.dump(lstm_model.state_dict(), f)
    
    # Save DistilBERT model
    with open('distilbert_model.pkl', 'wb') as f:
        pickle.dump(distilbert_model.state_dict(), f)
    
    # Save DistilBERT tokenizer
    with open('distilbert_tokenizer.pkl', 'wb') as f:
        pickle.dump(distilbert_tokenizer, f)

def main():
    print("Starting Viva Checker setup...")
    
    # Setup NLTK
    setup_nltk()
    
    # Define dataset files
    dataset_files = ['dataset.txt', 'student_answer_low.txt']
    
    # Create vocabulary and get training texts
    word_to_idx, train_texts = create_vocabulary(dataset_files)
    print(f"Vocabulary size: {len(word_to_idx)}")
    
    # Initialize models
    EMBEDDING_DIM = 100
    HIDDEN_DIM = 128
    vocab_size = len(word_to_idx)
    
    print("Initializing models...")
    lstm_model = LSTMModel(vocab_size, EMBEDDING_DIM, HIDDEN_DIM, HIDDEN_DIM)
    distilbert_tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')
    distilbert_model = DistilBertModel.from_pretrained('distilbert-base-uncased')
    
    # Train LSTM model
    if train_texts:
        train_model(lstm_model, distilbert_model, train_texts, word_to_idx)
    else:
        print("Warning: No training texts found. Models will be initialized but not trained.")
    
    # Save all models and tokenizer
    save_models(lstm_model, distilbert_model, distilbert_tokenizer)
    
    print("\nSetup completed successfully!")
    print("Created files:")
    print("- word_to_idx.json")
    print("- lstm_model.pkl")
    print("- distilbert_model.pkl")
    print("- distilbert_tokenizer.pkl")

if __name__ == "__main__":
    main()