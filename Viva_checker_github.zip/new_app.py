from flask import Flask, render_template, request, jsonify
import torch
import torch.nn as nn
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import string
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from fuzzywuzzy import fuzz
import numpy as np
from transformers import DistilBertTokenizer, DistilBertModel
import json
import pickle
import speech_recognition as sr
import threading
from flask_socketio import SocketIO, emit

app = Flask(__name__)
socketio = SocketIO(app)

# Download required NLTK data
nltk.download('punkt')
nltk.download('stopwords')

# Global variables
recording = False
recognized_text = ""
questions = []
current_question = 0
viva_results = []
student_details = None
total_maximum_marks = 0  # Added to track total maximum marks

# Load pre-trained models and data
word_to_idx = json.load(open('word_to_idx.json', 'r'))
EMBEDDING_DIM = 100
HIDDEN_DIM = 128
vocab_size = len(word_to_idx)

class LSTMModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, output_dim):
        super(LSTMModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, output_dim)
    
    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, _ = self.lstm(embedded)
        out = lstm_out[:, -1, :]
        out = self.fc(out)
        return out

# Initialize models
lstm_model = LSTMModel(vocab_size, EMBEDDING_DIM, HIDDEN_DIM, HIDDEN_DIM)
with open('lstm_model.pkl', 'rb') as f:
    lstm_model.load_state_dict(pickle.load(f))
lstm_model.eval()

# Load DistilBERT model and tokenizer
distilbert_model = DistilBertModel.from_pretrained('distilbert-base-uncased')
with open('distilbert_model.pkl', 'rb') as f:
    distilbert_model.load_state_dict(pickle.load(f))
distilbert_model.eval()

with open('distilbert_tokenizer.pkl', 'rb') as f:
    distilbert_tokenizer = pickle.load(f)

stop_words = set(stopwords.words('english'))
tfidf_vectorizer = TfidfVectorizer(stop_words='english')

def parse_question_file(content):
    """Parse the question file and calculate total maximum marks."""
    global total_maximum_marks
    questions = []
    lines = content.split('\n')
    current_data = {}
    total_marks = 0

    for line in lines:
        line = line.strip()
        if not line:  # Skip empty lines
            continue
            
        if line.startswith("Question:"):
            if current_data:
                if 'marks' not in current_data:
                    current_data['marks'] = 0  # Default marks if not specified
                questions.append(current_data)
                total_marks += current_data['marks']
            current_data = {'question': line[9:].strip()}
            
        elif line.startswith("Answer:"):
            current_data['answer'] = line[7:].strip()
            
        elif line.startswith("Marks:"):
            try:
                marks = float(line[6:].strip())
                current_data['marks'] = marks
            except ValueError:
                current_data['marks'] = 0  # Default to 0 if invalid marks
                
    # Add the last question
    if current_data:
        if 'marks' not in current_data:
            current_data['marks'] = 0
        questions.append(current_data)
        total_marks += current_data['marks']

    total_maximum_marks = total_marks
    return questions

def preprocess_text(text):
    """Preprocess text for analysis."""
    text = text.lower()
    text = text.translate(str.maketrans('', '', string.punctuation))
    tokens = word_tokenize(text)
    tokens = [word for word in tokens if word not in stop_words]
    return ' '.join(tokens)

def tokenize_and_pad(text, word_to_idx, max_length=512):
    """Tokenize and pad text for LSTM processing."""
    tokens = preprocess_text(text).split()
    sequence = [word_to_idx.get(token, word_to_idx['<UNK>']) for token in tokens]
    if len(sequence) < max_length:
        sequence = sequence + [word_to_idx['<PAD>']] * (max_length - len(sequence))
    else:
        sequence = sequence[:max_length]
    return torch.tensor(sequence, dtype=torch.long)

def get_lstm_embedding(text, model):
    """Get LSTM embeddings for text."""
    model.eval()
    with torch.no_grad():
        tokenized = tokenize_and_pad(text, word_to_idx).unsqueeze(0)
        embedding = model(tokenized)
    return embedding.squeeze().numpy()

def get_distilbert_embedding(text, model):
    """Get DistilBERT embeddings for text."""
    model.eval()
    with torch.no_grad():
        inputs = distilbert_tokenizer(text, return_tensors="pt", padding=True, truncation=True, max_length=512)
        outputs = model(**inputs)
        return outputs.last_hidden_state.mean(dim=1).squeeze().numpy()

def calculate_similarity(question, ref_answer, student_answer):
    """Calculate similarity between reference and student answers."""
    # Check for irrelevant or empty answers
    if not student_answer.strip() or fuzz.ratio(question.lower(), student_answer.lower()) > 80:
        return 0
    
    ref_processed = preprocess_text(ref_answer)
    student_processed = preprocess_text(student_answer)
    
    # Get various similarity scores
    ref_lstm = get_lstm_embedding(ref_processed, lstm_model)
    student_lstm = get_lstm_embedding(student_processed, lstm_model)
    lstm_similarity = cosine_similarity([ref_lstm], [student_lstm])[0][0]
    
    ref_bert = get_distilbert_embedding(ref_processed, distilbert_model)
    student_bert = get_distilbert_embedding(student_processed, distilbert_model)
    bert_similarity = cosine_similarity([ref_bert], [student_bert])[0][0]
    
    # Calculate TF-IDF similarity
    tfidf_matrix = tfidf_vectorizer.fit_transform([ref_processed, student_processed])
    tfidf_similarity = cosine_similarity(tfidf_matrix[0], tfidf_matrix[1])[0][0]
    
    # Calculate word overlap
    ref_words = set(ref_processed.split())
    student_words = set(student_processed.split())
    word_overlap = len(ref_words.intersection(student_words)) / max(len(ref_words.union(student_words)), 1)
    
    # Weighted combination of similarities
    combined_similarity = (
        0.4 * lstm_similarity +
        0.4 * bert_similarity +
        0.1 * tfidf_similarity +
        0.1 * word_overlap
    )
    
    return max(0, min(1, combined_similarity))  # Ensure result is between 0 and 1

def record_audio():
    """Record and transcribe audio in real-time."""
    global recording, recognized_text
    recognizer = sr.Recognizer()
    mic = sr.Microphone()

    with mic as source:
        recognizer.adjust_for_ambient_noise(source)
        
        while recording:
            try:
                audio = recognizer.listen(source, timeout=5)
                text = recognizer.recognize_google(audio, language="en-US")
                recognized_text += " " + text
                socketio.emit('transcription_update', {'text': recognized_text})
            except (sr.UnknownValueError, sr.RequestError, sr.WaitTimeoutError) as e:
                error_message = " [Inaudible]" if isinstance(e, sr.UnknownValueError) else f" [Error: {str(e)}]"
                recognized_text += error_message
                socketio.emit('transcription_update', {'text': recognized_text})

# Routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/submit_details', methods=['POST'])
def submit_details():
    """Submit student details."""
    global student_details
    student_details = {
        'name': request.form['name'],
        'id': request.form['student_id'],
        'course': request.form['course']
    }
    return jsonify({"status": "success"})

@app.route('/upload_questions', methods=['POST'])
def upload_questions():
    """Upload and parse questions file."""
    global questions
    file = request.files['file']
    if not file or not file.filename.endswith('.txt'):
        return jsonify({"status": "error", "message": "Please upload a valid .txt file"})
    
    content = file.read().decode('utf-8')
    questions = parse_question_file(content)
    
    return jsonify({
        "status": "success", 
        "message": "Questions uploaded successfully",
        "total_marks": total_maximum_marks,
        "question_count": len(questions)
    })

@app.route('/start_viva', methods=['GET'])
def start_viva():
    """Initialize viva examination."""
    global current_question, viva_results
    if not student_details:
        return jsonify({"status": "error", "message": "Please submit student details first"})
    if not questions:
        return jsonify({"status": "error", "message": "Please upload questions first"})
    
    current_question = 0
    viva_results = []
    return jsonify({
        "status": "success", 
        "total_questions": len(questions),
        "total_marks": total_maximum_marks
    })

@app.route('/get_question', methods=['GET'])
def get_question():
    """Get current question."""
    if current_question >= len(questions):
        return jsonify({"status": "completed"})
    return jsonify({
        "status": "success",
        "question": questions[current_question]["question"],
        "marks": questions[current_question]["marks"]
    })

@app.route('/toggle_recording', methods=['POST'])
def toggle_recording():
    """Toggle audio recording."""
    global recording, recognized_text
    recording = not recording
    
    if recording:
        recognized_text = ""
        threading.Thread(target=record_audio, daemon=True).start()
        return jsonify({"status": "started"})
    return jsonify({"status": "stopped"})

@app.route('/next_question', methods=['POST'])
def next_question():
    """Process current answer and move to next question."""
    global current_question, recognized_text, viva_results
    
    if current_question < len(questions):
        # Calculate score for current question
        similarity = calculate_similarity(
            questions[current_question]["question"],
            questions[current_question]["answer"],
            recognized_text.strip()
        )
        score = round(similarity * questions[current_question]["marks"], 2)
        
        # Store result
        viva_results.append({
            "question": questions[current_question]["question"],
            "expected_answer": questions[current_question]["answer"],
            "user_answer": recognized_text.strip(),
            "score": score,
            "max_score": questions[current_question]["marks"]
        })
        
        current_question += 1
        recognized_text = ""
        
        if current_question < len(questions):
            return jsonify({
                "status": "success",
                "question": questions[current_question]["question"],
                "marks": questions[current_question]["marks"],
                "progress": f"{current_question}/{len(questions)}"
            })
    
    return jsonify({
        "status": "completed",
        "message": "All questions completed"
    })

@app.route('/get_results', methods=['GET'])
def get_results():
    """Get final viva results."""
    if not viva_results:
        return jsonify({"status": "error", "message": "No results available"})
    
    total_obtained = sum(result["score"] for result in viva_results)
    percentage = (total_obtained / total_maximum_marks) * 100 if total_maximum_marks > 0 else 0
    
    return jsonify({
        "status": "success",
        "student": student_details,
        "results": viva_results,
        "total_marks": total_maximum_marks,
        "total_obtained": round(total_obtained, 2),
        "percentage": round(percentage, 2)
    })

if __name__ == '__main__':
    socketio.run(app, debug=True)